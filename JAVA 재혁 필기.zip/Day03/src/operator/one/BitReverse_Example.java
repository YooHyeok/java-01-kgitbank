package operator.one;

public class BitReverse_Example {

	public static void main(String[] args) {
		// ~ - 비트 반전 연산자, ! - 논리 반전 연산자
		byte a = 1;	//0000_0001

		System.out.println(~a); //1111_1110;
		
		boolean b = true;
		System.out.println(!b);
		
	}

}
