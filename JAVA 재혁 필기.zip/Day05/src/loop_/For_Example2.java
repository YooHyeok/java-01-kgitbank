package loop_;

public class For_Example2 {

	public static void main(String[] args) {
		for (int a = 0; a < 10; a++)
			System.out.print((a+1)+" "); //printf println print 차이와 + " " 출력문 구조식 알아보기...;;
	}

}
