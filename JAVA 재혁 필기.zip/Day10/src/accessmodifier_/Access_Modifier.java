//accessmodifier접근제한자

package accessmodifier_;

public class Access_Modifier {

	public static void main(String[] args) {
		Access_Example a1 = new Access_Example();
		//private는 내 클래스 이외에 참조 불가.
		//access example안에 d 변수 private int 형으로 초기화함.
		
//		System.out.println(a1.d);

	}

}
