package poly;

public class HerbAnimal {
	public String name;
}
