package poly;

public class Predator {
	
	public String name;
	
	public void eat() {
		
	}
	
}
