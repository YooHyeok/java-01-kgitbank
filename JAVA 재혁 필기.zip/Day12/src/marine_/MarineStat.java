package marine_;

public class MarineStat {
	
}
