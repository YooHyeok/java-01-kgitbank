package static_;

public class StaticInit_Example {

	public static void main(String[] args) {
		StaticInitial s1 = new StaticInitial();
		StaticInitial s2 = new StaticInitial();
	}

}
