package abstract_;

public class Banana extends Fruit{
	
	public Banana() {
		this.name = "바나나";
	}
}
