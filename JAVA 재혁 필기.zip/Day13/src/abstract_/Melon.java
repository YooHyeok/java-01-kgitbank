package abstract_;

public class Melon extends Fruit{
	public Melon() {
		this.name = "멜론";
	}
}