package abstract_;

public abstract class Shape {

	protected int x;
	protected int y;
	
	public abstract void getArea();
	
	
}
