package final_;

public final class FinalClass {

	public final void a() {

	}

}
