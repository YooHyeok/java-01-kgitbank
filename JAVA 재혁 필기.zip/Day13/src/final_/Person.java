package final_;

public class Person {

	public void eat() {
		
	}
}
