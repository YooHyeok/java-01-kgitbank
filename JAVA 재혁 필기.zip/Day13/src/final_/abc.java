package final_;

public class abc extends FinalClass {

	public void a() {
		
	}
}
