package interface_;

public abstract class Meat {

	static String name;
	
}
