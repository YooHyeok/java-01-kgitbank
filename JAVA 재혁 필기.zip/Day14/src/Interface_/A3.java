package Interface_;

public interface A3 extends A1, A2{ //A1과 A2를 상속
	
	void a3();
	
}
