package Interface_;

public interface A4 {

	void a4();
	
}
