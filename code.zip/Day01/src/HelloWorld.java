//클래스명은 파일과 동일해야 한다.
//클래스는 무조건 대문자로 시작
public class HelloWorld {
	//안에 적힌 내용을 실행해주는 메서드
	//main메서드가 없는 경우 해당 클래스는 ctrl+f11로 실행할 수 없음(사용은 가능)
	public static void main(String[] args) {
		//콘솔(시스템터미널)에 입력받은 값을 출력해주는 메서드.
		//sysout 작성 후 (ctrl+space)로 빠른 작성 가능
		System.out.println("Hello World!");
	}

}
