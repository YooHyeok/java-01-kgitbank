
public class BooleanExample {

	public static void main(String[] args) {
		//boolean은 1bit - 0 또는 1
		//해당 비트를 나타내는 키워드인 true, false만 가질 수 있음
		//나머지 값들은 수용 불가.
		boolean a = true;
//		boolean b = True;
//		boolean c = "true";
//		boolean d = 1;
	}

}
