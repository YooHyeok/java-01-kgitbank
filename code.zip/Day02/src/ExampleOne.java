import java.util.Arrays;

public class ExampleOne {

	public static void main(String[] args) {
		int[] a = {1,2,3};
		int[] b = a;
		a[0] = 2;
		System.out.println(Arrays.toString(b));
	}

}
