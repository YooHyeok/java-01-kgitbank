
public class FloatExample {

	public static void main(String[] args) {
		//4byte, 소수 7자리까지 표현
		//기본적으로 double로 취급하기 때문에
		//float을 사용하는 경우에는 f를 붙여줘야함
		float a = 1.1f;
		//8byte, 소수 15자리까지 표현
		double b = 1.2;
	}

}
