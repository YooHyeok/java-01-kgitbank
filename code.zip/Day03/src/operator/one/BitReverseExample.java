package operator.one;

public class BitReverseExample {

	public static void main(String[] args) {
		// ~ - 비트반전연산자, ! - 논리반전연산자
		byte a = 1; //0000_0001; 
		System.out.println(~a); //1111_1110;

		boolean b = true;
		System.out.println(!b);
	}

}
