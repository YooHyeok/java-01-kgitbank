package operator.two;

public class BitMoveExample {

	public static void main(String[] args) {
		// << 왼쪽으로 이동, 0을 채움
		// >> 오른쪽으로 이동, 부호비트 채움(맨 앞 비트가 0이면 0, 1이면 1)
		// >>> 오른쪽으로 이동, 부호비트 상관없이 무조건 0
		// <<, >> 는 이동 횟수만큼 2를 나누거나 곱하는 효과
		// >>>는 단순 비트 패턴을 추출하려 할 때 사용
		byte a = 2; //0000_0010;
		System.out.println(a<<2); //0000_1000 = 8;
		
		a = -128; //1000_0000;
		System.out.println(a>>2); //1110_0000 = -32;
		
		a = 64; //0100_0000;
		System.out.println(a>>2); //0001_0000 = 16;
		
		a = -128; //1000_0000;
		//부호비트 상관없이 0만 채우기 때문에 값이 변경될 수 있음
		System.out.println(a>>>2); //0010_0000 = 32;
	}

}
