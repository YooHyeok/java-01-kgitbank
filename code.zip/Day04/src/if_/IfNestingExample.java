package if_;

public class IfNestingExample {

	public static void main(String[] args) {
		int a = (int)(Math.random()*100)+1;

		if(a%2==0) {
			if(a%3==0) {
				if(a%5==0) {
					System.out.printf("%d는 2와 3과 5의 공배수입니다.",a);
				}else {
				System.out.printf("%d는 2와 3의 공배수입니다.",a);	
				}
			}else if(a%5==0) {
				System.out.printf("%d는 2와 5의 공배수입니다.",a);
			}else {
				System.out.printf("%d는 2의 배수입니다.",a);
			}
		}else if(a%3==0) {
			if(a%5==0) {
				System.out.printf("%d는 3과 5의 공배수입니다.",a);
			}else {
				System.out.printf("%d는 3의 배수입니다.",a);
			}
		}else if(a%5==0) {
			System.out.printf("%d는 5의 배수입니다.",a);
		}else {
			System.out.printf("%d는 2,3,5의 배수가 아닙니다.",a);
		}
	}

}
