package loop_;

public class DoWhileExample {

	public static void main(String[] args) {
		int i = 0;
		int sum = 0;
		//do 안에 실행 내용, 이후 while(조건식);
		do {
			sum = sum + ++i;
		}while(i<0);
		
		System.out.println(sum);
	}

}
