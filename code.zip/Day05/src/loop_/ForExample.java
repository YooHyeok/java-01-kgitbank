package loop_;

public class ForExample {

	public static void main(String[] args) {
		int sum = 0;
		//초기값 설정 - 조건식 확인 - 실행 - 증감표현식 실행 - 실행 - 증감..의 순서 
		for(int i = 0; i < 10; i++) {
			sum = sum + i;
		}
		System.out.println(sum);
	}

}
