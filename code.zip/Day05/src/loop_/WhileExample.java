package loop_;

public class WhileExample {

	public static void main(String[] args) {
		//while(조건식) - 조건식이 참인 경우에 실행
		int i = 0;
		int sum = 0;
		while(i<10) {
			sum += ++i;
		}
		System.out.println(sum);
		
		int a = 0;
		int b = 0;
		while(true) {
			a++;
			b += a;
			if(a==10) {
				break;
			}
		}
		System.out.println(b);
	}

}
