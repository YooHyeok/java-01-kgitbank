package switch_;

public class SwitchExample {

	public static void main(String[] args) {
		int a = (int)(Math.random()*100)+1;
		//switch(수식)의 형태로 작성 - 수식의 결과값은 int형 이하의 숫자,
		//String, Enum 형 가능
		switch(a%5) {
		//case (수식의결과값) : 해당 경우일 때 코드 내용
		//한 줄 한 줄 읽으며 실행하기 때문에 break가 필요
		//break 없을 시 해당 케이스부터 모든 케이스 전부 실행
		case 0 : 
			System.out.printf("%d는 5의 배수입니다.",a);
			break;
		//여러개의 case를 하나로 묶어서도 사용 가능
		case 1 :
		case 2 :
		case 3 :
			System.out.printf("%d는 5의 배수가 아닙니다.",a);
			break;
		//if문의 else와 같음 - 위의 case들 이외의 나머지 경우
		default : 
			System.out.printf("%d는 5의 배수에서 1이 모자랍니다.",a);
		}
	}

}
