import java.util.Scanner;

public class PalindromeEx {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String data = scan.nextLine();
		System.out.println(palindrome(data));
		scan.close();
	}
	
	public static boolean palindrome(String data) {
		for(int i=0; i<data.length()/2; i++) {
			if(data.charAt(i)!=data.charAt(data.length()-1-i)) {
				return false;
			}
		}
		return true;
	}

}
