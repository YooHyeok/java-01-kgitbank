package loop_;

public class ForEachExample {

	public static void main(String[] args) {
		String a = "abcde";
		for(int i=a.length(); i>0; i--) {
			System.out.print(a.charAt(i-1));
		}
		System.out.println();
		int[] arr = {1,2,3,4,5};
		for(int i=0; i<arr.length; i++) {
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		//forEach 문 - for(배열안의 값 타입 이름 : 배열)
		//배열의 값을 처음부터 하나씩 빼면서 실행 - 기존 for문의 연산 x
		//데이터를 하나씩 사용하는 경우 실행속도가 월등하게 빠름
		for(int b : arr) {
			System.out.print(b+" ");
		}
	}

}
