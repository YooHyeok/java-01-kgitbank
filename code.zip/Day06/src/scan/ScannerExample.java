package scan;

import java.util.Scanner;

public class ScannerExample {

	public static void main(String[] args) {
		//값을 입력받기 위해서 Scanner 객체 생성
		//System.out - 콘솔에 출력/ System.in - 콘솔에 입력
		Scanner scan = new Scanner(System.in);
		System.out.print("아무거나 입력해 주세요 :");
		//Scanner 객체 안의 scan.nextLine() - 입력하는 값을
		//String 값으로 돌려줌. 기준 문자는 개행문자.
		String data = scan.nextLine();
		System.out.println(data);
		System.out.println("아무거나 입력해 주세요 :");
		//scan.next() - 기준문자가 공백이기 때문에
		//공백이 들어가면 전체 값이 전송 안 됨
		data = scan.next();
		System.out.println(data);
		System.out.println("숫자만 입력해 주세요 :");
		int a = scan.nextInt();
		System.out.println(a);
		//자원을 할당 받았으면 항상 닫아줘야 함
		scan.close();
		
	}

}
