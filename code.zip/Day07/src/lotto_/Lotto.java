package lotto_;

import java.util.Arrays;

public class Lotto {

	public static void main(String[] args) {
		int index = 0;
		int[] lotto = new int[6];
		while(true) {
			int rand = (int)(Math.random()*45)+1;
			int i = 0;
			for(i=0; i<index; i++) {
				if(rand==lotto[i]) {
					break;
				}
			}
			if(i==index) {
				lotto[index++] = rand;
			}
			if(index==6) {
				break;
			}
		}
		System.out.println(Arrays.toString(lotto));
	}
}