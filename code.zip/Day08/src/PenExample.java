
public class PenExample {

	public static void main(String[] args) {
		//인스턴스 생성 - 클래스 식별자 = new 생성자;
		Pen pen = new Pen();
		//만들어진 인스턴스는 클래스 안의 메서드, 변수 보유 - 참조 가능
		pen.color = "검정";
		pen.width = 1;
		pen.price = 1000;
		System.out.printf("펜의 색깔은 %s 입니다.", pen.color);
		//클래스는 설계도이기 때문에 틀의 역할 - 인스턴스는 무한대로 생성 가능
		Pen redPen = new Pen();
		redPen.color = "빨강";
		System.out.printf("빨강펜의 색깔은 %s 입니다.", redPen.color);
	}

}
