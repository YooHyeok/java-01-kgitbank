package class_;

public class Account {

	public int accountNumber;
	public String password;
	public String name;
	public String bankName;
	public long balance;
	
	public void deposit(long money) {
		this.balance += money;
		System.out.printf("%s님의 계좌에 입금합니다.\n",this.name);
		System.out.printf("입금액 : %d, 잔액 : %d\n",money,this.balance);
	}
	
	public void withdraw(String password, long money) {
		if(checkPassword(password)) {
			if(money>this.balance) {
				System.out.printf("잔액이 부족합니다. 잔액 : %d\n",this.balance);
				return;
			}
			this.balance -= money;
			System.out.printf("%s님의 계좌에서 출금합니다.\n",this.name);
			System.out.printf("출금액 : %d, 잔액 : %d\n",money,this.balance);
		}else {
			System.out.println("비밀번호가 다릅니다.");
		}
	}
	
	private boolean checkPassword(String password) {
		return (password.equals(this.password)); 
	}
	
	public void transfer(String password, long money, Account account) {
		if(checkPassword(password)) {
			if(this.balance<money) {
				System.out.printf("잔액이 부족합니다. 현재 잔액 : %d\n",this.balance);
				return;
			}
			this.balance -= money;
			account.balance += money;
			System.out.printf("%s님의 계좌로 %d이 송금되었습니다.\n", account.name, money);
			System.out.printf("현재 잔액 : %d\n", this.balance);
		}else {
			System.out.println("비밀번호가 다릅니다.");
		}
	}
	
	public Account(String name, String bankName, String password) {
		this.accountNumber = (int)(Math.random()*100000)+1;
		this.name = name;
		this.bankName = bankName;
		this.password = password;
	}
	
	public void checkBalance(String password) {
		if(checkPassword(password)) {
			System.out.printf("%s님의 계좌\n",this.name);
			System.out.printf("현재 잔액 : %d\n",this.balance);
		}else {
			System.out.println("비밀번호가 다릅니다.");
		}
	}
	
	
	
	
	
	
	
}
