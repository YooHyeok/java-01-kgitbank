package class_;

public class AccountExample {
	
	public static void main(String[] args) {
		Account a1 = new Account("엄영범","신한","1234");
		Account a2 = new Account("노평례","국민","0000");
		a1.deposit(100000);
		a1.withdraw("1235", 50000);
		a1.withdraw("1234", 110000);
		a1.transfer("1234", 50000, a2);
		a1.checkBalance("1234");
		a2.checkBalance("0000");
	}

}
