package class_;

public class Dog {

	public String name;
	public int age;
	public double weight;
	public String species;
	public int hungry;
	
	public void eat() {
		System.out.printf("%s가 먹이를 먹었습니다.\n",this.name);
		this.hungry += 5;
		if(checkHungry()) {
			bark();
		}
	}
	
	public void walk() {
		System.out.printf("%s가 걸었습니다.\n",this.name);
		this.hungry -= 10;
		if(checkHungry()) {
			bark();
		}
	}
	
	public void sit() {
		System.out.printf("%s가 앉았습니다.\n",this.name);
		this.hungry -= 10;
		if(checkHungry()) {
			bark();
		}
	}
	
	public void bark() {
		System.out.printf("%s : 왈왈!\n",this.name);
		this.hungry -= 1;
	}
	
	public boolean checkHungry() {
		if(this.hungry<=30) {
			return true;
		}
		return false;
	}
	
	public Dog() {
		this.name = "이름없음";
		this.age = 1;
		this.hungry = 50;
		this.species = "견종없음";
		this.weight = 10;
	}
	
	public Dog(String name, int age, String species, double weight) {
		this.name = name;
		this.age = age;
		this.hungry = 50;
		this.species = species;
		this.weight = weight;
	}
	
}
