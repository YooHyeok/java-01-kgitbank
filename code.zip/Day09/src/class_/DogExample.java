package class_;

public class DogExample {

	public static void main(String[] args) {
		Dog d1 = new Dog();
		Dog d2 = new Dog("뽀삐", 10, "코커스파니엘", 25.7);
		d1.walk();
		d2.sit();
		d2.bark();
		d1.walk();
	}

}
