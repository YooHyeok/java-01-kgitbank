package accessmodifier_;

public class AccessModifier {

	public static void main(String[] args) {
		AccessExample a1 = new AccessExample();
		System.out.println(a1.d);
	}

}
