package accessmodifier_;

public class abc {

	public static void main(String[] args) {
		
	}

}
