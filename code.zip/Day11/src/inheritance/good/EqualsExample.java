package inheritance.good;

public class EqualsExample {

	public static void main(String[] args) {
		Person p1 = new Person("엄영범",21);
		Person p2 = new Person("엄영범",21);
		System.out.println(p1==p2);
		System.out.println(p1.equals(p2));
	}

}