package inheritance.good;

public class Student extends Person{

	public String school;
	
	public Student(String name, int age, String school) {
		super(name, age);
		this.school = school;
	}

	//상속받은 메서드를 자식 클래스에서 다시 구현 하는 것 - 재정의
	//@Override 어노테이션으로 표시 - 없어도 상관없음
	@Override
	public String speak() {
		return super.speak()+", 학교="+this.school;
	}
	
	
	
}
