package inheritance.good;

public class ToStringExample {

	public static void main(String[] args) {
		Person p = new Person("엄영범",21);
		print(p);
		print(10);
		print("문자열");
	}
	
	public static void print(Object a) {
		System.out.println(a.toString());
	}

}
