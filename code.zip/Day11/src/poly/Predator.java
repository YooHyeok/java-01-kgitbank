package poly;

public class Predator {

	public String name;
	
	public void eat() {
		System.out.println("프레데터실행");
	}
}
