package static_;

public class Count {

	public int a;
	public static int b;
	
}
