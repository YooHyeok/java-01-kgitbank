package static_;

public class Marine {

	public static int attack = 3;
	public static int defense = 3;
	public int hp = 40;
	
	public void underAttack(int damage) {
		System.out.println("공격받았습니다! 체력감소 :-"+damage);
		this.hp -= damage;
		System.out.println("현재 체력 : "+this.hp);
	}
	
	public static void upgradeAttack() {
		Marine.attack += 3;
	}
	
	public static void upgradeDefense() {
		Marine.defense += 3;
	}
	
}
