package static_;

public class StaticInitExample {

	public static void main(String[] args) {
		StaticInitial s1 = new StaticInitial();
		StaticInitial s2 = new StaticInitial();
	}

}
