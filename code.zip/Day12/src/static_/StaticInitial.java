package static_;

public class StaticInitial {

	static {
		System.out.println("스태틱 초기화자 실행");
	}
	
	public StaticInitial() {
		System.out.println("생성자 실행");
	}
	
}
