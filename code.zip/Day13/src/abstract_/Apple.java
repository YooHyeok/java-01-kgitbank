package abstract_;

public class Apple extends Fruit{
	
	public Apple() {
		this.name = "사과";
	}
	
}
