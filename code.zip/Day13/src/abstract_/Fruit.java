package abstract_;

public abstract class Fruit {

	String name;
	
}
