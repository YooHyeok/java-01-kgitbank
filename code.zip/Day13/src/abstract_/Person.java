package abstract_;

public class Person {

	public void eat(Fruit fruit) {
		System.out.println("사람이 "+fruit.name+"을/를 먹습니다.");
	}
	
	public static void main(String[] args) {
		Person p = new Person();
		p.eat(new Apple());
		p.eat(new Banana());
		p.eat(new Melon());
		//추상클래스는 객체 생성 불가
//		p.eat(new Fruit());
		//추상클래스를 자료형으로 가지는 객체는 선언 가능
		Fruit f = new Apple();
		
	}

}
