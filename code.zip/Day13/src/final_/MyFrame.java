package final_;

import java.awt.*;

public class MyFrame extends Frame{

	public MyFrame() {
		super("MyFrame");
		setSize(300,200);
		setVisible(true);
		add(new MyLabel());
	}
	
	public static void main(String[] args) {
		new MyFrame();
	}
	
	public class MyLabel extends Label{
		
		public MyLabel() {
			super("Name : ");
		}
	}
	
}
