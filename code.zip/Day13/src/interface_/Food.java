package interface_;

public interface Food {

	String getFood();
	
}
