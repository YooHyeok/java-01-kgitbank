package interface_;

public abstract class Fruit {

	String name;
	
}
