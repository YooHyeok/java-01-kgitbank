package interface_;

public abstract class Meat {

	String name;
	
}
