package interface_;

public class Melon extends Fruit implements Food{
	
	public Melon() {
		this.name = "멜론";
	}

	@Override
	public String getFood() {
		return this.name;
	}
	
}
