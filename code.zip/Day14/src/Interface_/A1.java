package Interface_;

public interface A1 {

	void a1();
	
}
