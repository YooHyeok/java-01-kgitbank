package exception_;

public class OverlapException extends Exception{

	public OverlapException(String message) {
		super(message);
	}
	
}
