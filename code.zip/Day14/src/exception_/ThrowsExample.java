package exception_;

public class ThrowsExample {

	public static void main(String[] args) {
		try {
		a();
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public static void a() throws Exception{
		String a = null;
		System.out.println(a.charAt(0));
	}

}
