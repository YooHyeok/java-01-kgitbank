package collection_;

import java.util.*;

public class HashSetExample {

	public static void main(String[] args) {
		HashSet<String> set = new HashSet<>();
		set.add("첫번째"); set.add("두번째"); set.add("세번째");
		System.out.println(set.add("첫번째"));
		System.out.println(set.size());
		System.out.println(set);
		set.remove("첫번째");
		System.out.println(set);
		set.add("네번째"); set.add("다섯번째");
		Iterator<String> i = set.iterator();
		while(i.hasNext()) {
			String data = i.next();
			if(data.length()==3) {
				System.out.println(data);
			}
		}
		for(String data : set) {
			System.out.println(data);
		}
		
		HashSet<Person> pset = new HashSet<>();
		pset.add(new Person("엄영범",10));
		pset.add(new Person("엄영범",10));
		System.out.println(pset.size());
		System.out.println(pset);
		
		Person[] parr = new Person[2];
		parr[0] = new Person("엄영범",10);
		parr[1] = new Person("엄영범",10);
		System.out.println(parr);
		
	}

}
