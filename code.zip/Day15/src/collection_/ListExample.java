package collection_;

import java.util.*;

public class ListExample {

	public static void main(String[] args) {
		ArrayList<Integer> alist = new ArrayList<>();
		LinkedList<Integer> llist = new LinkedList<>();
		for(int i=0; i<100000000; i++) {
			alist.add(i); llist.add(i);
		}
		double start = System.currentTimeMillis();
		alist.get(99999999);
		double end = System.currentTimeMillis();
		System.out.println((end-start));
		start = System.currentTimeMillis();
		llist.get(99999999);
		end = System.currentTimeMillis();
		System.out.println((end-start));
		
	}

}
