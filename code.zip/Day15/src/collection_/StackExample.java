package collection_;

import java.util.*;

public class StackExample {

	public static void main(String[] args) {
		Stack<Integer> stack = new Stack<>();
		stack.add(1); stack.push(2); stack.push(3);
		stack.add(4); stack.push(5);
		//List형태로 1번째(2번째)값 조회 = 2
		System.out.println(stack.get(1));
		//Stack형태로 2라는 값이 어디에 있는지 조회 = 4
		System.out.println(stack.search(2));
		
		while(!stack.empty()) {
			System.out.println(stack.pop());
		}
		System.out.println(stack.size());
		HashMap<String, Integer> map = new HashMap<>();
		map.put("첫번째", 1); map.put("두번째", 2);
		map.put("세번째", 3);
		
	}

}
