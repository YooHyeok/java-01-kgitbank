package collection_quest;

import java.util.*;

public class Lotto {

	public static void main(String[] args) {
		CollectionsLotto();
	}
	
	public static void setLotto() {
		TreeSet<Integer> set = new TreeSet<>();
		while(set.size()<6) {
			int ran = (int)(Math.random()*45)+1;
			set.add(ran);
		}
		System.out.println(set);
	}
	
	public static void CollectionsLotto() {
		ArrayList<Integer> list = new ArrayList<>();
		for(int i=1; i<=45; i++) {
			list.add(i);
		}
		System.out.println(list);
		//list 계열 객체만 가능. - 안의 값을 무작위로 섞음.
		//해당 리스트를 변경시킴 - 변경시킨 값을 리턴하는 구조가 아님
		Collections.shuffle(list);
		System.out.println(list);
		//크기 비교를 통해 안의 값들을 순서대로 정렬
		//마찬가지로 해당 객체를 변경 - 새로운 값을 리턴하는게 아님
		//자매품 - Arrays.sort = 배열의 값들 정렬
		Collections.sort(list);
		System.out.println(list);
		//이진탐색 - 반으로 나눠서 큰지 작은지 - 작다면 작은 범위를 다시 반으로
		//나누어 큰지 작은지 의 로직으로 탐색. 완전탐색보다 훨씬 빠른 속도
		//선행조건으로 크기순 정렬이 되어 있어야 가능함
		//자매품 - Arrays.binarySearch() = 크기정렬 되어 있어야 가능
		Collections.binarySearch(list, 31);
		//역순정렬 - reverse 메서드 또는 sort에 역순 Comparator 대입
		//기존 데이터 타입들의 역순은 Collections.reverseOrder()로 
		//호출 가능
		Collections.reverse(list);
		Collections.sort(list, Collections.reverseOrder());
		
	}

}
