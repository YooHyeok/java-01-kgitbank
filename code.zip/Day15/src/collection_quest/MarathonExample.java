package collection_quest;

import java.util.*;

public class MarathonExample {

	public static void main(String[] args) {
		String[] part = {"mislav", "stanko", "mislav", "ana"};
		String[] com = {"mislav", "stanko", "ana"};
		System.out.println(solution(part,com));
	}
	
	public static String solution(String[] part, String[] com) {
		HashMap<String, Integer> map = new HashMap<>();
		for(String man : part) {
			map.put(man, map.getOrDefault(man, 0)+1);
		}
		for(String man: com) {
			map.put(man, map.get(man)-1);
		}
		Set<String> keyset = map.keySet();
		for(String key : keyset) {
			if(map.get(key)==1) {
				return key;
			}
		}
		return null;
	}

}
