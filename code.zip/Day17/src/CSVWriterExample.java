import java.io.*;

public class CSVWriterExample {

	public static void main(String[] args) {
		FileReader fr = null;
		BufferedReader br = null;
		FileWriter fw = null;
		BufferedWriter bw = null;
		try {
			fr = new FileReader("customer.txt");
			br = new BufferedReader(fr);
			fw = new FileWriter("C:\\Users\\user\\Desktop\\customer.csv");
			bw = new BufferedWriter(fw);
			String data = null;
			int i=0;
			while((data=br.readLine())!=null) {
				System.out.println(++i+"번째 줄 읽음.");
				String[] dummy = data.split(",");
				for(String field : dummy) {
					bw.write(field); bw.write(",");
					//버퍼 안의 데이터 강제 출력
					bw.flush();
				}
				bw.newLine();
				bw.flush();
				System.out.println(i+"번째 줄 작성 완료.");
			}
			System.out.println("파일 작성 완료");
		}catch(IOException e) {
			System.out.println(e.getMessage());
		}finally {
			if(br!=null) { try {br.close();}catch(IOException e) {} }
		}
	}

}
