
import java.io.*;
import java.util.ArrayList;

public class CustomerReadExample {

	public static void main(String[] args) {
		FileInputStream fis = null;
		ObjectInputStream ois = null;
		try {
			fis = new FileInputStream("customer.data");
			ois = new ObjectInputStream(fis);
			ArrayList<Customer> cusList = 
					(ArrayList<Customer>)ois.readObject();
			System.out.println(cusList);
		}catch(IOException | ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}finally {
			if(ois!=null) { try {ois.close();}catch(IOException e) {} }
		}
	}

}
