
import java.io.*;

public class NodeStreamExample {

	public static void main(String[] args) {
		InputStreamReader fr = null;
		try {
			fr = new InputStreamReader(new FileInputStream("C:\\Users\\user\\Desktop\\Node.txt"),"MS949");
			char[] buffer = new char[256];
			int readCount = fr.read(buffer);
			while(readCount!=-1) {
				String data = new String(buffer,0,readCount);
				System.out.println(data);
				readCount = fr.read(buffer);
			}
			
		}catch(IOException e) {
			System.out.println(e.getMessage());
		}finally {
			if(fr!=null) { try{fr.close();}catch(IOException e) {} }
		}
	}

}
