
public class RegularExpressionExample {

	public static void main(String[] args) {
		String number = "010-132-1562";
		String number2 = "031-1234-3323";
		if(number.matches("^\\d{2,3}-\\d{3,4}-\\d{4}$")) {
			System.out.println(number);
		}
		if(number2.matches("^\\d{2,3}-\\d{3,4}-\\d{4}$")) {
			System.out.println(number2);
		}
		
		String email = "gctserf@gmail.com";
		String email2 = "gctserf@outlook.co.kr";
		if(email.matches("^[a-z]{1}\\w+@[a-z]{1,10}\\..+$")) {
			System.out.println(email);
		}if(email2.matches("^[a-z]{1}\\w+@[a-z]{1,10}\\..+$")) {
			System.out.println(email2);
		}
		
		String id = "001231-3080102";
		String id2 = "900731-1082012";
		if(id.matches("^[0-9]{6}-[1-4]{1}[0-9]{6}$")) {
			System.out.println(id);
		}
		if(id2.matches("^[0-9]{6}-[1-4]{1}[0-9]{6}$")) {
			System.out.println(id2);
		}
		
		String pid = id.replaceAll("-[1-4]{1}[0-9]{6}", "-*******");
		System.out.println(pid);
	}	

	
	
	
	
	
}
