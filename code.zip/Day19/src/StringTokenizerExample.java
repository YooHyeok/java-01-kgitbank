import java.util.StringTokenizer;

public class StringTokenizerExample {

	public static void main(String[] args) {
		String data = "this is a sample";
		StringTokenizer st = new StringTokenizer(data);
		System.out.println(st.countTokens());
		while(st.hasMoreTokens()) {
			System.out.println(st.nextToken());
		}
		data = "this.is a;sample,test";
		st = new StringTokenizer(data," .,;");
		while(st.hasMoreTokens()) {
			System.out.println(st.nextToken());
		}
		data = "엄영범,M,gctserf@gmail.com,21";
		st = new StringTokenizer(data,",",true);
		while(st.hasMoreTokens()) {
			System.out.println(st.nextToken());
		}
		
	}

}
